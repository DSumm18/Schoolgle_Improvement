# Gemini Live API notes for Ed

Use Ed's personality in the system instructions for the Live session.
Keep the voice settings calm and concise.
Prefer a measured pace and British English wording.

Recommended approach:
1. Start a Live API session.
2. Set response modality to audio if you want spoken replies.
3. Put Ed's character, rules, and module awareness into the system prompt.
4. Keep humour sparse.
5. Switch to an inspection mode prompt when you need zero humour.

For tightly controlled recited speech, use Gemini TTS instead of the Live API.
