
Schoolgle Marketing Asset Pack
Generated for Cursor Integration

Includes:
- Logo concepts (SVG)
- Planet orbit animation starter (Lottie JSON)
- Static genesis frame
- Homepage copy
- Product page copy
- Sales one-pager
- GDPR & Security copy
